function analyzeResume() {

    const text =
        document.getElementById("resume")
        .value
        .toLowerCase();

    const skills = [
        "html", "css", "javascript",
        "python", "java", "sql",
        "react", "cloud", "machine learning",
        "communication", "leadership"
    ];

    let found = [];

    skills.forEach(skill => {

        if (text.includes(skill)) {
            found.push(skill);
        }
    });

    let output = "";

    found.forEach(skill => {

        output +=
            `<span class="skill">${skill}</span>`;
    });

    document.getElementById("skills").innerHTML =
        output || "No matching skills found.";

    let score = Math.min(100, found.length * 10);

    document.getElementById("score").innerText =
        "Resume Score: " + score + "/100";
}